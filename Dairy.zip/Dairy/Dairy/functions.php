<?php


add_action( 'wp_enqueue_scripts', 'enqueue_parent_styles' );

function enqueue_parent_styles() {

  wp_enqueue_style( 'parent-style',  get_template_directory_uri().'style.css' );

}
//for display menu in admin panel
register_nav_menus(
  array('primary-menu' => 'Header Menu')
);




function my_custom_theme_enqueue() {
    wp_enqueue_style( 'my-custom-theme', get_stylesheet_uri() );
    wp_enqueue_script( 'my-scripts', get_template_directory_uri() . '/js/script.js' );
    }
    add_action( 'wp_enqueue_scripts', 'my_custom_theme_enqueue' );

    define('FS_METHOD', 'direct');


    add_action( 'rest_api_init', function() {
      register_rest_route( 'my/v1', '/projects', [
        'methods' => 'GET',
        'callback' => 'get_projects',
        'permission_callback' => '__return_true',
      ] );
    } );
    
    // Get all projects and assign thumbnail
    function get_projects( $params ) {
      $projects =  get_posts( [
        'post_type' => 'post',
        'posts_per_page' => 10
      ] );
    
      foreach( $projects as &$p ) {
        $p->thumbnail = get_the_post_thumbnail_url( $p->ID );
      }
    
      return $projects;
    }

//dyanmic route for post 
add_action( 'rest_api_init', function() {
  register_rest_route( 'my/v1', '/project/(?P<id>\d+)', [
    'methods' => 'GET',
    'callback' => 'get_project',
    'permission_callback' => '__return_true',
  ] );
} );

// Get single project
function get_project( $params ) {
  $project = get_post( $params['id'] );
  $project->thumbnail = get_the_post_thumbnail_url( $project->ID );
  return $project;
}



?>